package restcourse;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;

@ApplicationPath("course")
public class AppConfig extends ResourceConfig {

  public AppConfig () {
    packages("restcourse");
  }
}
